# Diagrama Sobre Hospital
Primeira PARTE/Secunda PARTE  e Script  do diagrama 
// feito em mermaid e // dbdiagram.io
